#include "Student.h"
#include "Person.h"

void Student::print_S() {
	std::cout << " grade : " << grade << "\n student_id : " << student_id << std::endl;
}