#include "Person.h"

void Person::print_P() {
	std::cout << " name : " << name << "\n age : " << age << std::endl;
}

