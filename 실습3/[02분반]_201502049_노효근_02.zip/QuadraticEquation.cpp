#include "QuadraticEquation.h"
bool QuadraticEquation::QuardraticEquation_calculateDisciminant(EquationCoefficient equation_coefficient) {
	
	double d = 0; 
	d = (equation_coefficient.b * equation_coefficient.b) - 4 * (equation_coefficient.a*equation_coefficient.c); 
	if (d < 0)
		return false;
	else if (d == 0)
		return true;
	else
		return true; 

}


EquationResult QuadraticEquation::QuardraticEquation_calculateQuadraticEquation(EquationCoefficient* equation_coefficient) {



	double d = 0; 
	EquationResult result; 
	d = (equation_coefficient->b * equation_coefficient->b) - 4.0 * (equation_coefficient->a*equation_coefficient->c); 


	if (d > 0) { 
		result.result1 = (equation_coefficient->b*-1 + sqrt(d)) / (2.0 * equation_coefficient->a);
		result.result2 = (equation_coefficient->b*-1 - sqrt(d)) / (2.0 * equation_coefficient->a);
		return result;
	}
	else if (d == 0) { 
		result.result1 = equation_coefficient->b*-1 / (2.0 *equation_coefficient->a);
		result.result2 = result.result1;
		return result;
	}

}